function n = ypea_get_total_code_length(vars)
    % Ruturns the Length of Coded Vectors Related to a Variable Set (Array)
    n = sum([vars.code_count]);
    
end