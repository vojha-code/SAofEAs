function p = ypea_path()
    % Returns installation directory of YPEA Toolbox
    
    [p, ~, ~] = fileparts(which('ypea_path.m'));
    
end